package com.hcutils.hclibrary.network;

public class TimeException extends RuntimeException {

    public TimeException(){

    }
}
