package com.hcutils.hclibrary.network;

public class TokenException extends RuntimeException {
   public TokenException(){

   }
}
